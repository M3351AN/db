$BOOTMODE || abort "! ONLY be installed on KernelSU"

[ $ARCH == "arm64" ] || abort "! ONLY support ARM64"

$KSU || abort abort "! ONLY support KernelSU "


ui_print " "
ui_print "- KSUVersion=$KSU_VER"
ui_print "- KSUVersionCode=$KSU_VER_CODE"
ui_print "- KSUKernelVersionCode=$KSU_KERNEL_VER_CODE"
sleep 1

ui_print "! If your App profile default setting is not UMOUNT, please change the value in default_umount.txt under module directory to 0 after reboot, and then execute the action to refresh"

chmod a+x $MODPATH/torikki-store
chmod a+x $MODPATH/post-fs-data.sh
chmod a+x $MODPATH/action.sh

#$MODPATH/torikki-store

ui_print " "

ui_print "- Installed success, please reboot."
