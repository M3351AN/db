# Most functions are intergrated in binary : torikki-store
# Check https://github.com/M3351AN/Torikki-Store/ for source
MODDIR=${0%/*}

sleep 15
$MODDIR/torikki-store
